sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("lockbox.templatebuilder.templateui4map.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map